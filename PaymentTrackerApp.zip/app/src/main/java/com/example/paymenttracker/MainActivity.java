package com.example.paymenttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText nameInput, amountInput, noteInput, searchInput;
    Spinner typeSpinner;
    Button addButton, searchButton;
    ListView listView;
    TextView balanceView;

    ArrayList<String> transactions = new ArrayList<>();
    ArrayAdapter<String> adapter;

    double totalCredit = 0, totalDebit = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        nameInput = findViewById(R.id.nameInput);
        amountInput = findViewById(R.id.amountInput);
        noteInput = findViewById(R.id.noteInput);
        searchInput = findViewById(R.id.searchInput);
        typeSpinner = findViewById(R.id.typeSpinner);
        addButton = findViewById(R.id.addButton);
        searchButton = findViewById(R.id.searchButton);
        listView = findViewById(R.id.listView);
        balanceView = findViewById(R.id.balanceView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, transactions);
        listView.setAdapter(adapter);

        typeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Credit", "Debit"}));

        addButton.setOnClickListener(v -> addTransaction());
        searchButton.setOnClickListener(v -> searchTransaction());
    }

    void addTransaction() {
        String name = nameInput.getText().toString();
        String amountStr = amountInput.getText().toString();
        String note = noteInput.getText().toString();
        String type = typeSpinner.getSelectedItem().toString();

        if (name.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Enter name and amount", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);
        String entry = type + ": " + name + " - ₹" + amount + " (" + note + ")";
        transactions.add(entry);
        adapter.notifyDataSetChanged();

        if (type.equals("Credit")) totalCredit += amount;
        else totalDebit += amount;

        updateBalance();
        clearInputs();
    }

    void updateBalance() {
        double balance = totalCredit - totalDebit;
        balanceView.setText("Balance: ₹" + balance);
    }

    void searchTransaction() {
        String keyword = searchInput.getText().toString().toLowerCase();
        ArrayList<String> filtered = new ArrayList<>();
        for (String entry : transactions) {
            if (entry.toLowerCase().contains(keyword)) {
                filtered.add(entry);
            }
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filtered);
        listView.setAdapter(adapter);
    }

    void clearInputs() {
        nameInput.setText("");
        amountInput.setText("");
        noteInput.setText("");
    }
}
